import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const ProductsPage = () => {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get('http://localhost:5000/products');
        setProducts(response.data);
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    };

    fetchProducts();
  }, []);

  const addToCart = (product) => {
    setCart(prevCart => ({
      ...prevCart,
      [product.id]: { ...product, quantity: (prevCart[product.id]?.quantity || 0) + 1 }
    }));
  };

  const removeFromCart = (productId) => {
    setCart(prevCart => {
      const newCart = { ...prevCart };
      if (newCart[productId]?.quantity > 1) {
        newCart[productId].quantity -= 1;
      } else {
        delete newCart[productId];
      }
      return newCart;
    });
  };

  const handleViewCart = () => {
    navigate('/cart', { state: { cart } });
  };

  const handlePlaceOrder = () => {
    navigate('/order-confirmation', { state: { cart } });
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Products</h2>
      <table className="table table-striped table-hover">
        <thead className="table-dark">
          <tr>
            <th>ProductId</th>
            <th>Product Name</th>
            <th>Product Price</th>
            <th>Product Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.map(product => (
            <tr key={product.id}>
              <td>{product.id}</td>
              <td>{product.name}</td>
              <td>${product.price.toFixed(2)}</td>
              <td>{product.description}</td>
              <td>
                <button 
                  className="btn btn-warning btn-sm me-2" 
                  onClick={() => removeFromCart(product.id)}
                  disabled={!cart[product.id]}
                >
                  Remove
                </button>
                <span className="me-2">{cart[product.id]?.quantity || 0}</span>
                <button 
                  className="btn btn-info btn-sm" 
                  onClick={() => addToCart(product)}
                >
                  Add Cart
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="btn btn-success mt-3" onClick={handleViewCart}>View Cart</button>
      <button className="btn btn-primary mt-3 ms-3" onClick={handlePlaceOrder}>Place Order</button>
    </div>
  );
};

export default ProductsPage;
