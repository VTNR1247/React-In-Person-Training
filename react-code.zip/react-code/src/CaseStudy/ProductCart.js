import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const ProductCart = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const cart = location.state?.cart || {};

  const handleRemove = (productId) => {
    const updatedCart = { ...cart };
    delete updatedCart[productId];
    navigate('/cart', { state: { cart: updatedCart } });
  };

  const handlePlaceOrder = () => {
    navigate('/order-confirmation', { state: { cart } });
  };

  const getTotal = () => {
    let total = 0;
    Object.values(cart).forEach(item => {
      total += item.price * item.quantity;
    });
    return total.toFixed(2);
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Cart</h2>
      <table className="table table-striped table-hover">
        <thead className="table-dark">
          <tr>
            <th>ProductId</th>
            <th>Product Name</th>
            <th>Product Price</th>
            <th>Quantity</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {Object.values(cart).map(item => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>{item.name}</td>
              <td>${item.price.toFixed(2)}</td>
              <td>{item.quantity}</td>
              <td>
                <button className="btn btn-danger btn-sm" onClick={() => handleRemove(item.id)}>Remove</button>
              </td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td colSpan="4" className="text-end">Total:</td>
            <td>${getTotal()}</td>
          </tr>
        </tfoot>
      </table>
      <button className="btn btn-primary mt-3" onClick={handlePlaceOrder}>Place Order</button>
    </div>
  );
};

export default ProductCart;
