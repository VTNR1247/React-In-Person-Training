import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const OrderSuccess = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const total = location.state?.total || 0;

  const handleBackToProducts = () => {
    navigate('/products');
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4 text-center">Order Placed Successfully!</h2>
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card p-4 text-center">
            <p className="mb-3">Your order was placed successfully with a total price of <strong>${total}</strong>.</p>
            <button
              className="btn btn-success mt-3"
              onClick={handleBackToProducts}
            >
              Go Back to Products
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderSuccess;
