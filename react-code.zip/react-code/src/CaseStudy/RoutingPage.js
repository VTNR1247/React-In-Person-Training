import React from 'react';
import { Route, Routes } from 'react-router-dom';
import LoginPage from './LoginPage';
import RegisterPage from './RegisterPage';
import ProductsPage from './ProductsPage';
import ProductCart from './ProductCart';
import OrderConfirmation from './OrderConfirmation';
import OrderSuccess from './OrderSuccess';

export default function Login() {
  return (
    <div className="container">
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/products" element={<ProductsPage />} />
        <Route path="/cart" element={<ProductCart />} />
        <Route path="/order-confirmation" element={<OrderConfirmation />} />
        <Route path="/order-success" element={<OrderSuccess />} />
      </Routes>
    </div>
  )
}
