import React from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const RegisterPage = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const navigate = useNavigate();
  const onSubmit = async (data) => {
    try {
      await axios.post('http://localhost:5000/users', data);
      alert('Registration successful!');
      navigate('/');
    } catch (error) {
      console.error('Error registering user:', error);
      alert('Registration failed!');
    }
  };

  const handleLoginRedirect = () => {
    navigate('/');
  };

  return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      <div className="card p-4">
        <h2 className="mb-4">Register</h2>
        <form onSubmit={handleSubmit(onSubmit)}>
          <table className="w-100">
            <tbody>
              <tr>
                <td className="pe-3">
                  <label className="form-label">Username</label>
                </td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    {...register('username', {
                      required: 'Username is required',
                      minLength: {
                        value: 5,
                        message: 'Username must be at least 5 characters'
                      },
                      pattern: {
                        value: /^(?=.*\d)[a-zA-Z\d]{5,}$/,
                        message: 'Username must contain at least one number'
                      }
                    })}
                  />
                  {errors.username && <span className="text-danger">{errors.username.message}</span>}
                </td>
              </tr>
              <tr>
                <td className="pe-3">
                  <label className="form-label">Email</label>
                </td>
                <td>
                  <input
                    type="email"
                    className="form-control"
                    {...register('email', {
                      required: 'Email is required',
                      pattern: {
                        value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                        message: 'Invalid email address'
                      }
                    })}
                  />
                  {errors.email && <span className="text-danger">{errors.email.message}</span>}
                </td>
              </tr>
              <tr>
                <td className="pe-3">
                  <label className="form-label">Password</label>
                </td>
                <td>
                  <input
                    type="password"
                    className="form-control"
                    {...register('password', {
                      required: 'Password is required',
                      pattern: {
                        value: /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/,
                        message: 'Password must contain at least one capital letter, one number, and one special character'
                      }
                    })}
                  />
                  {errors.password && <span className="text-danger">{errors.password.message}</span>}
                </td>
              </tr>
            </tbody>
          </table>
          <button type="submit" className="btn btn-primary w-100 mt-3">Register</button>
        </form>
        <button onClick={handleLoginRedirect} className="btn btn-link mt-3">Login</button>
      </div>
    </div>
  );
};

export default RegisterPage;
