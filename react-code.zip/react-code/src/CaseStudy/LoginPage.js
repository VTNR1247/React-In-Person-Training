import React from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const LoginPage = () => {
  const { register, handleSubmit, watch, formState: { errors } } = useForm();
  const navigate = useNavigate();
  const onSubmit = async (data) => {
    try {
      const response = await axios.get('http://localhost:5000/users');
      const users = response.data;
      const user = users.find(user => user.username === data.username && user.password === data.password);
      if (user) {
        alert('Login successful!');
        navigate('/products');
      } else {
        alert('Invalid username or password!');
      }
    } catch (error) {
      console.error('Error logging in:', error);
      alert('Login failed!');
    }
  };

  const handleRegisterRedirect = () => {
    navigate('/register');
  };

  const isFormValid = watch('username') && watch('password');

  return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      <div className="card p-4">
        <h2 className="mb-4">Login</h2>
        <form onSubmit={handleSubmit(onSubmit)}>
          <table className="w-100">
            <tbody>
              <tr>
                <td className="pe-3">
                  <label className="form-label">Username</label>
                </td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    {...register('username', { required: true })}
                  />
                  {errors.username && <span className="text-danger">Username is required</span>}
                </td>
              </tr>
              <tr>
                <td className="pe-3">
                  <label className="form-label">Password</label>
                </td>
                <td>
                  <input
                    type="password"
                    className="form-control"
                    {...register('password', { required: true })}
                  />
                  {errors.password && <span className="text-danger">Password is required</span>}
                </td>
              </tr>
            </tbody>
          </table>
          <button type="submit" className="btn btn-primary w-100 mt-3" disabled={!isFormValid}>Login</button>
        </form>
        <button onClick={handleRegisterRedirect} className="btn btn-link mt-3">Register</button>
      </div>
    </div>
  );
};

export default LoginPage;
