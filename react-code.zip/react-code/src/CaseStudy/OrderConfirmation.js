import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const OrderConfirmation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const cart = location.state?.cart || {};
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [paymentMode, setPaymentMode] = useState('');
  const [isFormValid, setIsFormValid] = useState(false);

  useEffect(() => {
    setIsFormValid(deliveryAddress.trim() !== '' && paymentMode.trim() !== '');
  }, [deliveryAddress, paymentMode]);

  const handleConfirmOrder = () => {
    navigate('/order-success', { state: { cart, total: getTotal() } });
  };

  const getTotal = () => {
    let total = 0;
    Object.values(cart).forEach(item => {
      total += item.price * item.quantity;
    });
    return total.toFixed(2);
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4 text-center">Order Confirmation</h2>
      <div className="row justify-content-center">
        <div className="col-md-8">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>ProductId</th>
                <th>Product Name</th>
                <th>Product Price</th>
                <th>Quantity</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {Object.values(cart).map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.name}</td>
                  <td>${item.price.toFixed(2)}</td>
                  <td>{item.quantity}</td>
                  <td>${(item.price * item.quantity).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan="4" className="text-end">Total:</td>
                <td>${getTotal()}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
      <div className="row justify-content-center mt-4">
        <div className="col-md-6">
          <div className="card p-4 bg-light">
            <h4 className="mb-3 text-center">Delivery Details</h4>
            <form>
              <div className="mb-3 row">
                <label htmlFor="deliveryAddress" className="col-sm-4 col-form-label">Enter Delivery Address:</label>
                <div className="col-sm-8">
                  <textarea
                    id="deliveryAddress"
                    className="form-control"
                    value={deliveryAddress}
                    onChange={(e) => setDeliveryAddress(e.target.value)}
                    style={{ borderColor: '#007bff', backgroundColor: '#e9f7ff' }}
                  />
                </div>
              </div>
              <div className="mb-3 row">
                <label htmlFor="paymentMode" className="col-sm-4 col-form-label">Enter Payment Mode:</label>
                <div className="col-sm-8">
                  <input
                    type="text"
                    id="paymentMode"
                    className="form-control"
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value)}
                    style={{ borderColor: '#007bff', backgroundColor: '#e9f7ff' }}
                  />
                </div>
              </div>
              <div className="d-grid gap-2">
                <button
                  type="button"
                  className="btn btn-primary mt-3"
                  onClick={handleConfirmOrder}
                  disabled={!isFormValid}
                  style={{ backgroundColor: '#007bff', borderColor: '#007bff' }}
                >
                  Confirm Order
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmation;
